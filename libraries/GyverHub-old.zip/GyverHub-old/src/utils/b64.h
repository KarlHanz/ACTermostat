#pragma once
#include <Arduino.h>

char GH_b64v(uint8_t n);
uint8_t GH_b64i(char b);
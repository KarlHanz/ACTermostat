/*
    Простой менеджер WiFi для esp8266 для задания логина-пароля WiFi и режима работы
    GitHub: https://github.com/GyverLibs/SimplePortal
    
    AlexGyver, alex@alexgyver.ru
    https://alexgyver.ru/
    MIT License

    Версии:
    v1.1 - совместимость с ESP32
*/

#define SP_AP_NAME "Esp Config"     // название точки
#define SP_AP_IP 192,168,1,1        // IP точки

#ifndef _TemplateWiFI_h
#define _TemplateWiFI_h
#include <DNSServer.h>
#ifdef ESP8266
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#else
#include <WiFi.h>
#include <WebServer.h>
#endif

#define SP_ERROR 0
#define SP_SUBMIT 1
#define SP_EXIT 4
#define SP_TIMEOUT 5

struct TemplateCfg {
  char SSID[32] = "";
  char pass[32] = "";
  uint8_t mode = WIFI_AP;    // (1 WIFI_STA, 2 WIFI_AP)
};
extern TemplateCfg templateCfg;

void templateStart();     // запустить портал
void templateStop();      // остановить портал
bool templateTick();      // вызывать в цикле
void templateRun(uint32_t prd = 60000);   // блокирующий вызов
byte templateStatus();    // статус: 1 connect, 4 exit, 5 timeout

void SP_handleConnect();
void SP_handleAP();
void SP_handleLocal();
void SP_handleExit();
#endif